export const GET_SAMPLE = "GET_SAMPLE";
export const SAMPLE_ERROR = "SAMPLE_ERROR";
