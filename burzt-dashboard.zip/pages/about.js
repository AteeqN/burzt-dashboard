import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";

function About() {
  return (
    <div className="container">
      <h1>About Page</h1>
    </div>
  );
}

export default About;
