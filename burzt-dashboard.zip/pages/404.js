import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
function NotFound({ data }) {
  return (
    <div className="container text-center">
      {" "}
      <h1>Page Not Found 404</h1>{" "}
    </div>
  );
}

export default NotFound;
