function Footer() {
  return (
    <div className="container">
      <ul className="nav justify-content-center">@Copyright Burzt Team</ul>
    </div>
  );
}

export default Footer;
